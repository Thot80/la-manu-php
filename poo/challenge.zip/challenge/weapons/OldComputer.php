<?php

class OldComputer extends Weapon{
    function __construct(){
        parent::__construct('Ordinateur Vieillissant', 400, 700);
    }
}