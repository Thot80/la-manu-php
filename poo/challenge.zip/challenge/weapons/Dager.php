<?php
class Dager extends Weapon{

    function __construct(){
        parent::__construct('Dague Empoisonnée', 600, 800);
    }
}