<?php
class Espadon extends Weapon{
    
    function __construct()
    {
        parent::__construct('Espadon', 400, 600);
    }
}