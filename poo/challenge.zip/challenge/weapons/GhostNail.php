<?php

class GhostNail extends Weapon{
    function __construct()
    {
        parent::__construct('Ongles du Revenant', 200, 400);
    }
}