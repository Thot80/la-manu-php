<?php

class Fleau extends Weapon{
    function __construct()
    {
        parent::__construct('Fléau', 500, 800); 
    }
}