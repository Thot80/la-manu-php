<?php

class Masse extends Weapon{
    function __construct(){
        parent:: __construct('Masse d\'arme', 700, 1000);
    }
}