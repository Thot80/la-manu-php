<?php

class MagicStick extends Weapon {

    function __construct()
    {
        parent::__construct('Bâton de Flammes Froides', 600, 800);
    }
}