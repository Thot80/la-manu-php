<?php

class SystemErrorArmor extends Armor{
    function __construct()
    {
        parent::__construct('Armure d\'Erreurs Système', 10, 600);
    }
}