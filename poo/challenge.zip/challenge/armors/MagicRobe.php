<?php

class MagicRobe extends Armor{
    function __construct()
    {
        parent::__construct('Robe Noire', 500, 700);
    }
}