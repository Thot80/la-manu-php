<?php

class WireArmor extends Armor{
    function __construct(){
        parent::__construct('Armure de câbles RJ-45', 300, 600);
    }
}