<?php

class PikeArmor extends Armor{
    function __construct()
    {
        parent::__construct('Armure de Piques', 700, 1000);
    }
}