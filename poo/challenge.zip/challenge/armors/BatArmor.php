<?php
class BatArmor extends Armor{
    function __construct(){
        parent::__construct('Armure en Peau de Chauve-Souris', 500, 700);
    }
}