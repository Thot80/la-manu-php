<?php

class ThiefCap extends Armor{
    function __construct()
    {
        parent::__construct('Cap de voleur', 300, 400);
    }
}