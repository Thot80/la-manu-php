<?php

class PlateArmor extends Armor{
    function __construct(){
        parent::__construct('Armure de Plaques', 800, 1500);
    }
}