<?php

class SkinArmor extends Armor{
    function __construct(){
        parent::__construct('Je suis à poil mec !', 0, 0);
    }
}